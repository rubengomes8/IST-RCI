# RCI Peer-to-Peer Stream Delivery Network

O objetivo deste projeto é o desenvolvimento de uma aplicação, designada **iamroot**, com a qual um conjunto de pares mantêm uma rede em ávore, construída à base de sessões TCP estabelecidas entre eles, a qual é usada para a disseminação de um conteúdo **stream** disponibilizado por um servidor TCP designado **fonte**.
